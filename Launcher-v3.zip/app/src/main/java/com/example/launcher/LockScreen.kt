package com.example.launcher

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.graphics.*
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.text.TextUtils
import android.view.*
import android.view.WindowManager.LayoutParams as WLP
import android.widget.*
import java.io.File

/** Wallpaper picked inside the launcher is stored here and reused as the lock screen background. */
fun wallFile(c: Context) = File(c.filesDir, "wallpaper.jpg")

fun loadWall(c: Context): Bitmap? {
    val f = wallFile(c)
    if (!f.exists()) return null
    return try {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        var s = 1
        while (o.outWidth / (s * 2) >= 1080) s *= 2
        BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
    } catch (e: Throwable) { null }
}

fun blend(a: Int, b: Int, t: Float): Int {
    fun m(x: Int, y: Int) = (x + (y - x) * t).toInt().coerceIn(0, 255)
    return Color.rgb(m(Color.red(a), Color.red(b)), m(Color.green(a), Color.green(b)), m(Color.blue(a), Color.blue(b)))
}

/** Fingerprint sensor look-alike. [progress] fills the rings with the accent colour while a finger is held. */
class FpView(c: Context, private val accent: Int) : View(c) {
    var active = false
    var progress = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 5f; strokeCap = Paint.Cap.ROUND }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    override fun onDraw(cv: Canvas) {
        val cx = width / 2f; val cy = height / 2f; val u = width / 12f
        glow.color = (accent and 0xFFFFFF) or ((if (active) 0x44 else 0x18) shl 24)
        cv.drawCircle(cx, cy, width / 2f - 2f, glow)
        for (i in 1..5) {
            p.color = if (progress * 5f >= i - 0.5f) accent else 0x99FFFFFF.toInt()
            cv.drawArc(cx - i * u, cy - i * u, cx + i * u, cy + i * u, 200f, 300f, false, p)
        }
    }
}

class NotifListener : NotificationListenerService() {
    companion object {
        @Volatile var items: List<Pair<String, String>> = emptyList()
        @Volatile var onChange: (() -> Unit)? = null
    }
    override fun onListenerConnected() = push()
    override fun onNotificationPosted(s: StatusBarNotification) = push()
    override fun onNotificationRemoved(s: StatusBarNotification) = push()
    private fun push() {
        items = try {
            activeNotifications.filter { !it.isOngoing && it.packageName != packageName }.map {
                val e = it.notification.extras
                (e.getCharSequence(Notification.EXTRA_TITLE) ?: "").toString() to (e.getCharSequence(Notification.EXTRA_TEXT) ?: "").toString()
            }.filter { it.first.isNotEmpty() || it.second.isNotEmpty() }
        } catch (e: Exception) { emptyList() }
        onChange?.invoke()
    }
}

class LockActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private lateinit var gestures: GestureDetector
    private lateinit var list: LinearLayout
    private var scan: ValueAnimator? = null
    private var unlocking = false

    private fun hasNotifAccess() =
        Settings.Secure.getString(contentResolver, "enabled_notification_listeners")?.contains(packageName) == true

    private fun fillList() {
        list.removeAllViews()
        val items = NotifListener.items
        if (items.isEmpty()) {
            if (!hasNotifAccess()) list.addView(TextView(this).apply {
                text = "Tap here to show notifications on the lock screen"; setTextColor(0xAAFFFFFF.toInt()); textSize = 12f
                gravity = Gravity.CENTER; setPadding(dp(14), dp(10), dp(14), dp(10))
                setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            })
            return
        }
        items.take(5).forEach { (t, x) ->
            list.addView(TextView(this).apply {
                text = if (x.isEmpty()) t else "$t\n$x"; setTextColor(Color.WHITE); textSize = 13f; maxLines = 3
                ellipsize = TextUtils.TruncateAt.END; setPadding(dp(14), dp(10), dp(14), dp(10))
                background = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(0x33FFFFFF) }
            }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setShowWhenLocked(true); setTurnScreenOn(true)
        val accent = P.accent(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(20), dp(60), dp(20), dp(36))
            val wall = loadWall(this@LockActivity)
            if (wall != null) { background = BitmapDrawable(resources, wall); foreground = ColorDrawable(0x77000000) }
            else background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0xFF0E1320.toInt(), blend(0xFF1D2540.toInt(), accent, 0.35f)))
        }
        root.addView(TextClock(this).apply {
            format12Hour = "h:mm"; format24Hour = "HH:mm"; textSize = 84f; setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL)
        })
        root.addView(TextClock(this).apply { format12Hour = "EEEE, d MMMM"; format24Hour = "EEEE, d MMMM"; textSize = 16f; setTextColor(0xCCFFFFFF.toInt()) })

        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(24) })
        fillList()

        val fp = FpView(this, accent)
        val status = TextView(this).apply { text = "Hold to unlock"; setTextColor(0x99FFFFFF.toInt()); textSize = 13f; setPadding(0, dp(10), 0, 0) }

        fp.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    if (!unlocking) {
                        fp.active = true; status.text = "Scanning…"
                        fp.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                        scan?.cancel()
                        scan = ValueAnimator.ofFloat(fp.progress, 1f).apply {
                            duration = 700
                            addUpdateListener { fp.progress = it.animatedValue as Float; fp.invalidate() }
                            addListener(object : AnimatorListenerAdapter() {
                                private var cancelled = false
                                override fun onAnimationCancel(a: Animator) { cancelled = true }
                                override fun onAnimationEnd(a: Animator) {
                                    if (cancelled) return
                                    unlocking = true; status.text = "Unlocked ✓"
                                    fp.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                                    unlock()
                                }
                            })
                            start()
                        }
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> if (!unlocking) {
                    scan?.cancel(); fp.active = false; status.text = "Hold to unlock"
                    scan = ValueAnimator.ofFloat(fp.progress, 0f).apply {
                        duration = 250
                        addUpdateListener { fp.progress = it.animatedValue as Float; fp.invalidate() }
                        start()
                    }
                }
            }
            true
        }
        root.addView(fp, LinearLayout.LayoutParams(dp(84), dp(84)))
        root.addView(status)
        setContentView(root)

        gestures = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 != null && e1.y - e2.y > dp(120) && vy < -600) { unlock(); return true }
                return false
            }
        })
    }

    override fun onStart() {
        super.onStart()
        unlocking = false
        NotifListener.onChange = { runOnUiThread { fillList() } }
        fillList()
    }

    override fun onStop() {
        NotifListener.onChange = null
        super.onStop()
    }

    private fun unlock() {
        val km = getSystemService(KeyguardManager::class.java)
        if (!km.isKeyguardLocked) { finish(); return }
        // On a PIN/pattern/fingerprint-protected phone the system still asks for the real credential here.
        km.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
            override fun onDismissSucceeded() { finish() }
            override fun onDismissCancelled() { unlocking = false }
            override fun onDismissError() { unlocking = false }
        })
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean { gestures.onTouchEvent(ev); return super.dispatchTouchEvent(ev) }

    @Deprecated("Back is disabled on the lock screen")
    override fun onBackPressed() {}
}

class LockService : Service() {
    private var handle: View? = null
    private var panelRoot: View? = null
    private val screenOff = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            c.startActivity(Intent(c, LockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION))
        }
    }

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("lock", "Lock screen", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "lock").setSmallIcon(android.R.drawable.ic_lock_lock).setContentTitle("Custom lock screen is on").build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(1, n)
        registerReceiver(screenOff, IntentFilter(Intent.ACTION_SCREEN_OFF))
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (handle == null && Settings.canDrawOverlays(this)) addHandle()
        return START_STICKY
    }

    override fun onDestroy() {
        unregisterReceiver(screenOff)
        handle?.let { try { wm().removeView(it) } catch (e: Exception) {} }
        panelRoot?.let { try { wm().removeView(it) } catch (e: Exception) {} }
        super.onDestroy()
    }

    override fun onBind(i: Intent?): IBinder? = null
    private fun wm() = getSystemService(WindowManager::class.java)

    // Small touch strip under the status bar, top-right: swipe down to open the control center over any app
    private fun addHandle() {
        val d = resources.displayMetrics.density
        val sbId = resources.getIdentifier("status_bar_height", "dimen", "android")
        val sb = if (sbId > 0) resources.getDimensionPixelSize(sbId) else (24 * d).toInt()
        var y0 = 0f; var fired = false
        val h = View(this)
        h.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { y0 = e.rawY; fired = false }
                MotionEvent.ACTION_MOVE -> if (!fired && e.rawY - y0 > 40 * d) { fired = true; showPanel() }
            }
            true
        }
        val lp = WLP((150 * d).toInt(), (26 * d).toInt(), WLP.TYPE_APPLICATION_OVERLAY,
            WLP.FLAG_NOT_FOCUSABLE or WLP.FLAG_NOT_TOUCH_MODAL or WLP.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.END; lp.y = sb
        wm().addView(h, lp); handle = h
    }

    private fun showPanel() {
        if (panelRoot != null) return
        val d = resources.displayMetrics.density
        val root = FrameLayout(this)
        val close = { try { wm().removeView(root) } catch (e: Exception) {}; panelRoot = null }
        root.setBackgroundColor(0x88000000.toInt()); root.setOnClickListener { close() }
        val panel = buildPanel(this) { close() }
        root.addView(panel, FrameLayout.LayoutParams(-1, -2, Gravity.TOP).apply {
            setMargins((10 * d).toInt(), (48 * d).toInt(), (10 * d).toInt(), 0)
        })
        wm().addView(root, WLP(-1, -1, WLP.TYPE_APPLICATION_OVERLAY, WLP.FLAG_NOT_FOCUSABLE or WLP.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT))
        panelRoot = root
        panel.translationY = -400f; panel.alpha = 0f
        panel.animate().translationY(0f).alpha(1f).setDuration(220).start()
    }
}
