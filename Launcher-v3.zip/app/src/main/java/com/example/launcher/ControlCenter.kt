package com.example.launcher

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.*

var torchOn = false

/** iOS-style vertical slider: a rounded glass bar that fills from the bottom while you drag. */
class VSlider(c: Context, private val icon: String, private val accent: Int, private val max: Int, cur: Int, private val onChange: (Int) -> Unit) : View(c) {
    private var value = cur.coerceIn(0, max)
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x33FFFFFF }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val clip = Path()

    override fun onDraw(cv: Canvas) {
        val r = width / 2f
        val rect = RectF(0f, 0f, width.toFloat(), height.toFloat())
        cv.drawRoundRect(rect, r, r, track)
        clip.reset(); clip.addRoundRect(rect, r, r, Path.Direction.CW)
        cv.save(); cv.clipPath(clip)
        val top = height - height * (value.toFloat() / max)
        cv.drawRect(0f, top, width.toFloat(), height.toFloat(), fill)
        cv.restore()
        txt.textSize = width * 0.38f
        cv.drawText(icon, width / 2f, height - width * 0.45f, txt)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        parent?.requestDisallowInterceptTouchEvent(true)
        if (e.action == MotionEvent.ACTION_DOWN || e.action == MotionEvent.ACTION_MOVE) {
            val p = 1f - (e.y / height).coerceIn(0f, 1f)
            val nv = (p * max).toInt().coerceIn(0, max)
            if (nv != value) { value = nv; invalidate(); onChange(nv) }
        }
        return true
    }
}

fun buildPanel(c: Context, dismiss: () -> Unit): View {
    val d = c.resources.displayMetrics.density
    fun dp(v: Int) = (v * d).toInt()
    val accent = P.accent(c)
    fun bg(col: Int, r: Int) = GradientDrawable().apply { cornerRadius = dp(r).toFloat(); setColor(col) }
    fun circle(col: Int) = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(col) }
    fun go(i: Intent) { dismiss(); c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    fun askWrite() = c.startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${c.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

    val wifiOn = try { (c.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).isWifiEnabled } catch (e: Exception) { false }
    val airOn = try { Settings.Global.getInt(c.contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1 } catch (e: Exception) { false }

    // Round toggle button with a label underneath
    fun round(icon: String, label: String, on: Boolean = false, tap: (View) -> Unit): View = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
        layoutParams = GridLayout.LayoutParams().apply {
            width = 0; height = -2; columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
            setMargins(dp(2), dp(6), dp(2), dp(6))
        }
        val b = TextView(c).apply {
            text = icon; textSize = 22f; gravity = Gravity.CENTER
            background = circle(if (on) accent else 0x44FFFFFF)
        }
        addView(b, LinearLayout.LayoutParams(dp(58), dp(58)))
        addView(TextView(c).apply { text = label; textSize = 11f; setTextColor(0xDDFFFFFF.toInt()); gravity = Gravity.CENTER; setPadding(0, dp(5), 0, 0) })
        setOnClickListener { tap(b) }
    }

    fun card(): LinearLayout = LinearLayout(c).apply { background = bg(0x33FFFFFF, 26); setPadding(dp(10), dp(8), dp(10), dp(8)) }

    val grid = GridLayout(c).apply { columnCount = 4 }
    grid.addView(round("📶", "Wi-Fi", wifiOn) { go(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)) })
    grid.addView(round("🔵", "Bluetooth") { go(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) })
    grid.addView(round("✈️", "Airplane", airOn) { go(Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS)) })
    grid.addView(round("🔦", "Torch", torchOn) { v ->
        try {
            val cm = c.getSystemService(CameraManager::class.java)
            val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            if (id != null) { torchOn = !torchOn; cm.setTorchMode(id, torchOn); v.background = circle(if (torchOn) accent else 0x44FFFFFF) }
        } catch (e: Exception) { Toast.makeText(c, "Torch not available", Toast.LENGTH_SHORT).show() }
    })
    grid.addView(round("🔄", "Rotate") {
        if (Settings.System.canWrite(c)) {
            val cur = Settings.System.getInt(c.contentResolver, Settings.System.ACCELEROMETER_ROTATION, 1)
            Settings.System.putInt(c.contentResolver, Settings.System.ACCELEROMETER_ROTATION, 1 - cur)
            it.background = circle(if (cur == 1) 0x44FFFFFF else accent)
            Toast.makeText(c, if (cur == 1) "Rotation locked" else "Auto-rotate on", Toast.LENGTH_SHORT).show()
        } else askWrite()
    })
    grid.addView(round("🔒", "Lock") { dismiss(); c.startActivity(Intent(c, LockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) })
    grid.addView(round("📷", "Camera") { go(Intent(MediaStore.ACTION_IMAGE_CAPTURE)) })
    grid.addView(round("⚙️", "Settings") { go(Intent(Settings.ACTION_SETTINGS)) })

    val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    val briCur = try { Settings.System.getInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128) } catch (e: Exception) { 128 }

    val bri = VSlider(c, "☀️", accent, 255, briCur) { p ->
        if (Settings.System.canWrite(c)) {
            Settings.System.putInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
            Settings.System.putInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS, p.coerceAtLeast(1))
        } else askWrite()
    }
    val vol = VSlider(c, "🔊", accent, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC), am.getStreamVolume(AudioManager.STREAM_MUSIC)) {
        am.setStreamVolume(AudioManager.STREAM_MUSIC, it, 0)
    }

    val tilesCard = card().apply { addView(grid, LinearLayout.LayoutParams(0, -2, 1f)) }
    val sliders = LinearLayout(c).apply {
        addView(bri, LinearLayout.LayoutParams(dp(64), dp(150)).apply { setMargins(0, 0, dp(10), 0) })
        addView(vol, LinearLayout.LayoutParams(dp(64), dp(150)))
    }

    val handle = View(c).apply { background = bg(0x66FFFFFF, 3) }

    return LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(10), dp(14), dp(16)); isClickable = true
        background = bg(0xCC10141F.toInt(), 34)
        addView(handle, LinearLayout.LayoutParams(dp(40), dp(5)).apply { gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = dp(10) })
        addView(LinearLayout(c).apply {
            addView(tilesCard, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(0, 0, dp(10), 0) })
            addView(sliders, LinearLayout.LayoutParams(-2, -2))
        })
        // Swipe up anywhere on the panel to close it
        var y0 = 0f
        setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> y0 = e.rawY
                MotionEvent.ACTION_UP -> if (y0 - e.rawY > dp(60)) dismiss()
            }
            false
        }
    }
}

class ControlCenter(private val a: Activity) : Dialog(a, android.R.style.Theme_Translucent_NoTitleBar) {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val m = (10 * a.resources.displayMetrics.density).toInt()
        val panel = buildPanel(a) { dismiss() }
        setContentView(FrameLayout(a).apply {
            setBackgroundColor(0x88000000.toInt()); setOnClickListener { dismiss() }
            addView(panel, FrameLayout.LayoutParams(-1, -2, Gravity.TOP).apply { setMargins(m, m * 4, m, 0) })
        })
        window?.setLayout(-1, -1)
        panel.translationY = -400f; panel.alpha = 0f
        panel.animate().translationY(0f).alpha(1f).setDuration(220).start()
    }
}
