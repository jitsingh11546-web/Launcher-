package com.example.launcher

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.WallpaperManager
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.*
import android.view.inputmethod.EditorInfo
import android.widget.*
import java.io.FileOutputStream

class Item(val label: String, val ri: ResolveInfo?, val folder: String?)

class MainActivity : Activity() {
    private var all = listOf<Item>()
    private val shown = mutableListOf<Item>()
    private lateinit var grid: GridView
    private lateinit var search: EditText
    private lateinit var dock: LinearLayout
    private lateinit var gestures: GestureDetector

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun pkg(i: Item) = i.ri!!.activityInfo.packageName
    private fun round(col: Int, r: Int) = GradientDrawable().apply { cornerRadius = dp(r).toFloat(); setColor(col) }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    @Suppress("DEPRECATION")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val accent = P.accent(this)
        val soft = (accent and 0xFFFFFF) or 0x55000000
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setOnApplyWindowInsetsListener { v, i -> v.setPadding(0, i.systemWindowInsetTop, 0, i.systemWindowInsetBottom); i }
        }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(24), dp(16), dp(24), dp(8))
            setOnLongClickListener { menu(); true }
        }
        head.addView(TextClock(this).apply { format12Hour = "h:mm"; format24Hour = "HH:mm"; textSize = 52f; setTextColor(Color.WHITE) })
        head.addView(TextClock(this).apply { format12Hour = "EEEE, d MMMM"; format24Hour = "EEEE, d MMMM"; textSize = 14f; setTextColor(0xCCFFFFFF.toInt()) })
        root.addView(head)

        search = EditText(this).apply {
            hint = "Search apps"; setHintTextColor(0x99FFFFFF.toInt()); setTextColor(Color.WHITE); textSize = 15f
            setSingleLine(); background = round(soft, 20); setPadding(dp(16), dp(10), dp(16), dp(10))
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            setOnEditorActionListener { _, _, _ ->
                shown.firstOrNull { it.ri != null }?.let { open(it.ri!!); setText("") }
                true
            }
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { refresh() }
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, bf: Int, c: Int) {}
            })
        }
        root.addView(search, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(20), dp(4), dp(20), dp(8)) })

        grid = GridView(this).apply {
            numColumns = 4; selector = ColorDrawable(Color.TRANSPARENT)
            adapter = object : BaseAdapter() {
                override fun getCount() = shown.size
                override fun getItem(p: Int) = shown[p]
                override fun getItemId(p: Int) = p.toLong()
                override fun getView(p: Int, v: View?, parent: ViewGroup) = cell(shown[p], 52, true)
            }
            setOnItemClickListener { _, _, p, _ -> val x = shown[p]; if (x.folder != null) openFolder(x.folder) else open(x.ri!!) }
            setOnItemLongClickListener { _, _, p, _ -> val x = shown[p]; if (x.folder != null) folderMenu(x.folder) else appMenu(x); true }
        }
        root.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f))

        dock = LinearLayout(this).apply { gravity = Gravity.CENTER; background = round(soft, 26); setPadding(dp(8), dp(4), dp(8), dp(4)) }
        root.addView(dock, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(16), dp(4), dp(16), dp(10)) })
        setContentView(root)

        gestures = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 != null && e1.y < dp(150) && e2.y - e1.y > dp(80) && vy > 600) { ControlCenter(this@MainActivity).show(); return true }
                return false
            }
        })
        if (!Settings.canDrawOverlays(this))
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
    }

    override fun onResume() {
        super.onResume()
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        all = packageManager.queryIntentActivities(q, 0).filter { it.activityInfo.packageName != packageName }
            .map { Item(it.loadLabel(packageManager).toString(), it, null) }.sortedBy { it.label.lowercase() }
        refresh()
        startForegroundService(Intent(this, LockService::class.java))
    }

    private fun cell(x: Item, w: Int, label: Boolean): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(4), dp(10), dp(4), dp(10))
        if (x.ri != null) addView(ImageView(context).apply { setImageDrawable(x.ri.loadIcon(packageManager)); layoutParams = LinearLayout.LayoutParams(dp(w), dp(w)) })
        else addView(folderIcon(x.folder ?: "", w).apply { layoutParams = LinearLayout.LayoutParams(dp(w), dp(w)) })
        if (label) addView(TextView(context).apply {
            text = x.label; setTextColor(Color.WHITE); textSize = 11f; maxLines = 1; gravity = Gravity.CENTER
            ellipsize = TextUtils.TruncateAt.END; setShadowLayer(4f, 0f, 1f, Color.BLACK); setPadding(0, dp(6), 0, 0)
        })
    }

    // Folder icon = rounded square with up to 4 mini app icons inside (iOS style)
    private fun folderIcon(name: String, w: Int): View {
        val apps = (folders()[name] ?: emptyList()).mapNotNull { k -> all.firstOrNull { pkg(it) == k } }.take(4)
        val box = GridLayout(this).apply {
            columnCount = 2; rowCount = 2; background = round(0x55FFFFFF, 14); setPadding(dp(5), dp(5), dp(5), dp(5))
        }
        val s = (w - 14) / 2
        apps.forEach { a ->
            box.addView(ImageView(this).apply { setImageDrawable(a.ri!!.loadIcon(packageManager)) },
                GridLayout.LayoutParams().apply { width = dp(s); height = dp(s); setMargins(dp(1), dp(1), dp(1), dp(1)) })
        }
        return box
    }

    private fun folders(): LinkedHashMap<String, List<String>> {
        val m = LinkedHashMap<String, List<String>>()
        P.get(this, "folders").forEach { m[it.substringBefore("~")] = it.substringAfter("~").split(",").filter { s -> s.isNotEmpty() } }
        return m
    }
    private fun saveFolders(m: Map<String, List<String>>) = P.put(this, "folders", m.map { "${it.key}~${it.value.joinToString(",")}" })

    private fun refresh() {
        val q = search.text.toString().trim().lowercase()
        val fs = folders()
        val inF = fs.values.flatten().toSet()
        shown.clear()
        if (q.isEmpty()) fs.keys.forEach { shown.add(Item(it, null, it)) }
        shown.addAll(all.filter { it.label.lowercase().contains(q) && (q.isNotEmpty() || pkg(it) !in inF) })
        (grid.adapter as BaseAdapter).notifyDataSetChanged()
        dock.removeAllViews()
        P.get(this, "dock").mapNotNull { d -> all.firstOrNull { pkg(it) == d } }.forEach { x ->
            dock.addView(cell(x, 46, false).apply {
                setOnClickListener { open(x.ri!!) }
                setOnLongClickListener { toggleDock(x); true }
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        dock.visibility = if (dock.childCount == 0) View.GONE else View.VISIBLE
    }

    private fun toggleDock(x: Item) {
        val d = P.get(this, "dock"); val k = pkg(x)
        if (k in d) d.remove(k) else if (d.size < 5) d.add(k) else toast("Dock is full")
        P.put(this, "dock", d); refresh()
    }

    private fun appMenu(x: Item) {
        val inDock = pkg(x) in P.get(this, "dock")
        val opts = arrayOf(if (inDock) "Remove from dock" else "Add to dock", "Add to folder", "App info")
        AlertDialog.Builder(this).setItems(opts) { _, w ->
            when (w) {
                0 -> toggleDock(x)
                1 -> pickFolder(x)
                else -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${pkg(x)}")))
            }
        }.show()
    }

    private fun pickFolder(x: Item) {
        val names = folders().keys.toList()
        AlertDialog.Builder(this).setTitle("Add to folder").setItems((names + "New folder…").toTypedArray()) { _, w ->
            if (w < names.size) addTo(names[w], x) else {
                val et = EditText(this).apply { hint = "Folder name" }
                AlertDialog.Builder(this).setTitle("New folder").setView(et).setPositiveButton("Create") { _, _ ->
                    val n = et.text.toString().trim().replace("~", "").replace("|", "").replace(",", "")
                    if (n.isNotEmpty()) addTo(n, x)
                }.show()
            }
        }.show()
    }

    private fun addTo(name: String, x: Item) {
        val fs = folders().mapValues { it.value.toMutableList() }.toMutableMap()
        fs.values.forEach { it.remove(pkg(x)) }
        fs.getOrPut(name) { mutableListOf() }.add(pkg(x))
        saveFolders(fs); refresh()
    }

    private fun removeFrom(name: String, x: Item) {
        val fs = folders().mapValues { it.value.toMutableList() }.toMutableMap()
        fs[name]?.remove(pkg(x))
        if (fs[name]?.isEmpty() == true) fs.remove(name)
        saveFolders(fs); refresh()
    }

    private fun folderMenu(name: String) {
        AlertDialog.Builder(this).setTitle(name).setItems(arrayOf("Rename folder", "Delete folder")) { _, w ->
            if (w == 0) renameFolder(name)
            else { val fs = folders().toMutableMap(); fs.remove(name); saveFolders(fs); refresh() }
        }.show()
    }

    private fun renameFolder(old: String) {
        val et = EditText(this).apply { setText(old) }
        AlertDialog.Builder(this).setTitle("Rename folder").setView(et).setPositiveButton("Save") { _, _ ->
            val n = et.text.toString().trim().replace("~", "").replace("|", "").replace(",", "")
            if (n.isNotEmpty() && n != old && n !in folders().keys) {
                val m = LinkedHashMap<String, List<String>>()
                folders().forEach { (k, v) -> m[if (k == old) n else k] = v }
                saveFolders(m); refresh()
            }
        }.show()
    }

    private fun openFolder(name: String) {
        val apps = (folders()[name] ?: return).mapNotNull { k -> all.firstOrNull { pkg(it) == k } }
        var dlg: AlertDialog? = null
        val g = GridView(this).apply {
            numColumns = 4
            adapter = object : BaseAdapter() {
                override fun getCount() = apps.size
                override fun getItem(p: Int) = apps[p]
                override fun getItemId(p: Int) = p.toLong()
                override fun getView(p: Int, v: View?, parent: ViewGroup) = cell(apps[p], 48, true)
            }
            setOnItemClickListener { _, _, p, _ -> dlg?.dismiss(); open(apps[p].ri!!) }
            setOnItemLongClickListener { _, _, p, _ -> removeFrom(name, apps[p]); dlg?.dismiss(); true }
        }
        dlg = AlertDialog.Builder(this).setTitle(name).setView(g).show()
    }

    private fun menu() {
        AlertDialog.Builder(this).setItems(arrayOf("Wallpaper from gallery", "System wallpaper picker", "Theme color", "Lock screen notifications")) { _, w ->
            when (w) {
                0 -> startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 77)
                1 -> startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Wallpaper"))
                2 -> AlertDialog.Builder(this).setTitle("Theme color").setItems(P.themes.map { it.first }.toTypedArray()) { _, i ->
                    P.sp(this).edit().putInt("theme", i).apply(); recreate()
                }.show()
                else -> startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        }.show()
    }

    // Picked image becomes both the home wallpaper and the lock screen background
    @Suppress("DEPRECATION")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req != 77 || res != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
            var sample = 1
            while (o.outWidth / (sample * 2) >= 1440) sample *= 2
            val bmp: Bitmap = contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
            } ?: return
            FileOutputStream(wallFile(this)).use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            WallpaperManager.getInstance(this).setBitmap(bmp)
            toast("Wallpaper set")
        } catch (e: Exception) { toast("Could not set wallpaper") }
    }

    private fun open(ri: ResolveInfo) = startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        .setClassName(ri.activityInfo.packageName, ri.activityInfo.name)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED))

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean { gestures.onTouchEvent(ev); return super.dispatchTouchEvent(ev) }

    @Deprecated("Stay on home")
    override fun onBackPressed() { search.setText("") }
}
